import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import * as schema from "@db/schema";
import * as relations from "@db/relations";
import path from "path";
import fs from "fs";

const dbDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const dbPath = path.join(dbDir, "services.db");
const sqlite = new Database(dbPath);

const fullSchema = { ...schema, ...relations };

export function getDb() {
  return drizzle(sqlite, { schema: fullSchema });
}
