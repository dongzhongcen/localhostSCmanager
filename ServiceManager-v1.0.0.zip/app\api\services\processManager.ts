import { spawn, type ChildProcess } from "child_process";
import { getDb } from "../queries/connection";
import { services } from "@db/schema";
import { eq } from "drizzle-orm";
import path from "path";
import fs from "fs";

const runningProcesses = new Map<number, ChildProcess>();

// Ensure logs directory exists
const logsDir = path.join(process.cwd(), "data", "logs");
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

function getLogPath(serviceId: number) {
  return path.join(logsDir, `service_${serviceId}.log`);
}

function parseCommand(command: string) {
  // Simple command parsing - handle quotes
  const args: string[] = [];
  let current = "";
  let inQuotes = false;
  let quoteChar = "";

  for (let i = 0; i < command.length; i++) {
    const char = command[i];
    if (!inQuotes && (char === '"' || char === "'")) {
      inQuotes = true;
      quoteChar = char;
    } else if (inQuotes && char === quoteChar) {
      inQuotes = false;
      quoteChar = "";
    } else if (!inQuotes && char === " ") {
      if (current) {
        args.push(current);
        current = "";
      }
    } else {
      current += char;
    }
  }

  if (current) {
    args.push(current);
  }

  return {
    command: args[0] || "",
    args: args.slice(1),
  };
}

export async function startService(serviceId: number) {
  const db = getDb();
  const service = db.select().from(services).where(eq(services.id, serviceId)).get();

  if (!service) {
    throw new Error("Service not found");
  }

  // Check if already running
  if (service.pid && isProcessRunning(service.pid)) {
    return { success: true, message: "Service is already running", pid: service.pid };
  }

  const { command, args } = parseCommand(service.command);
  
  if (!command) {
    throw new Error("Invalid command");
  }

  // Parse environment variables
  const env: Record<string, string> = {};
  if (process.env) {
    for (const [key, value] of Object.entries(process.env)) {
      if (value !== undefined) {
        env[key] = value;
      }
    }
  }
  if (service.envVars) {
    try {
      const customEnv = JSON.parse(service.envVars);
      Object.assign(env, customEnv);
    } catch {
      // Ignore invalid env JSON
    }
  }

  // Open log file
  const logPath = getLogPath(serviceId);
  const logStream = fs.createWriteStream(logPath, { flags: "a" });

  const now = new Date().toISOString();
  logStream.write(`\n[${now}] Starting service: ${service.name}\n`);
  logStream.write(`[${now}] Command: ${service.command}\n`);

  const child = spawn(command, args, {
    cwd: service.cwd || process.cwd(),
    env,
    detached: false,
    shell: true,
    windowsHide: true, // Hide console window on Windows
  });

  // Store reference
  runningProcesses.set(serviceId, child);

  child.stdout?.on("data", (data: Buffer) => {
    logStream.write(`[${new Date().toISOString()}] [STDOUT] ${data.toString()}`);
  });

  child.stderr?.on("data", (data: Buffer) => {
    logStream.write(`[${new Date().toISOString()}] [STDERR] ${data.toString()}`);
  });

  child.on("exit", (code) => {
    const exitTime = new Date().toISOString();
    logStream.write(`[${exitTime}] Process exited with code ${code}\n`);
    logStream.end();

    runningProcesses.delete(serviceId);

    // Update status in database
    db.update(services)
      .set({
        status: code === 0 ? "stopped" : "error",
        pid: null,
      })
      .where(eq(services.id, serviceId))
      .run();
  });

  child.on("error", (err) => {
    logStream.write(`[${new Date().toISOString()}] [ERROR] ${err.message}\n`);
    logStream.end();
    runningProcesses.delete(serviceId);

    db.update(services)
      .set({
        status: "error",
        pid: null,
      })
      .where(eq(services.id, serviceId))
      .run();
  });

  // Update database with PID
  const pid = child.pid;
  if (pid) {
    db.update(services)
      .set({
        status: "running",
        pid,
      })
      .where(eq(services.id, serviceId))
      .run();
  }

  return { success: true, message: "Service started", pid };
}

export async function stopService(serviceId: number) {
  const db = getDb();
  const service = db.select().from(services).where(eq(services.id, serviceId)).get();

  if (!service) {
    throw new Error("Service not found");
  }

  const child = runningProcesses.get(serviceId);

  if (child) {
    // Try graceful kill first
    child.kill("SIGTERM");
    
    // Force kill after 5 seconds if still running
    setTimeout(() => {
      if (!child.killed) {
        child.kill("SIGKILL");
      }
    }, 5000);

    runningProcesses.delete(serviceId);
  } else if (service.pid) {
    // Try to kill by PID if we have it but not in memory
    try {
      process.kill(service.pid, "SIGTERM");
    } catch {
      // Process already dead
    }
  }

  db.update(services)
    .set({
      status: "stopped",
      pid: null,
    })
    .where(eq(services.id, serviceId))
    .run();

  return { success: true, message: "Service stopped" };
}

export async function restartService(serviceId: number) {
  await stopService(serviceId);
  // Wait a bit for the process to fully stop
  await new Promise((resolve) => setTimeout(resolve, 1000));
  return startService(serviceId);
}

export function getServiceLogs(serviceId: number, lines: number = 100) {
  const logPath = getLogPath(serviceId);

  if (!fs.existsSync(logPath)) {
    return [];
  }

  const content = fs.readFileSync(logPath, "utf-8");
  const allLines = content.split("\n").filter((l) => l.trim());
  return allLines.slice(-lines);
}

export function clearServiceLogs(serviceId: number) {
  const logPath = getLogPath(serviceId);
  if (fs.existsSync(logPath)) {
    fs.writeFileSync(logPath, "");
  }
}

function isProcessRunning(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export async function getServiceStatus(serviceId: number) {
  const db = getDb();
  const service = db.select().from(services).where(eq(services.id, serviceId)).get();

  if (!service || !service.pid) {
    return { status: "stopped", pid: null };
  }

  const running = isProcessRunning(service.pid);

  if (!running && service.status === "running") {
    // Process died but db still shows running
    db.update(services)
      .set({ status: "stopped", pid: null })
      .where(eq(services.id, serviceId))
      .run();
    return { status: "stopped", pid: null };
  }

  return { status: running ? "running" : service.status, pid: service.pid };
}

// Clean up all running processes on shutdown
export function cleanupProcesses() {
  for (const [_id, child] of runningProcesses.entries()) {
    try {
      child.kill("SIGTERM");
    } catch {
      // Ignore errors during cleanup
    }
  }
  runningProcesses.clear();
}

// Auto-start services on boot
export async function autoStartServices() {
  const db = getDb();
  const autoStartServices = db.select().from(services).where(eq(services.autoStart, true)).all();

  for (const service of autoStartServices) {
    try {
      await startService(service.id);
    } catch (err) {
      console.error(`Failed to auto-start service ${service.name}:`, err);
    }
  }
}
