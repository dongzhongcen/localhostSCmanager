import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";

export function useServiceStatuses(pollInterval = 3000) {
  const [statuses, setStatuses] = useState<Record<number, { status: string; pid: number | null }>>({});
  
  const utils = trpc.useUtils();
  
  useEffect(() => {
    const fetchStatuses = async () => {
      try {
        const result = await utils.client.service.statuses.query();
        setStatuses(result);
      } catch {
        // Ignore errors during polling
      }
    };

    fetchStatuses();
    const interval = setInterval(fetchStatuses, pollInterval);
    return () => clearInterval(interval);
  }, [utils, pollInterval]);

  return statuses;
}
